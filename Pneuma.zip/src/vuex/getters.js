const getUsername = state => {
    return state.username;
}

const getUserID = state => {
    return state.userID;
}

export default {
    getUsername,
    getUserID
}